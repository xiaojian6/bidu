<?php

namespace App\Models;

class ChainHash extends Model
{
    
}

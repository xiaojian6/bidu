<?php

namespace App\Models;

class Bank extends Model
{
    protected $table = 'bank';
    public $timestamps = false;
}

<?php

namespace App\Models;

class ExchangeShiftTo extends Model
{
    protected $table = 'exchange_shift_to';
}

<?php

namespace App\Models;

class LbxHash extends Model
{
    protected $attributes = [
        'status' => 0,
    ];
}

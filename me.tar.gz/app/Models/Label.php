<?php

namespace App\Models;

class Label extends Model
{
    protected $table = 'label';
    public $timestamps = false;
}

<?php

namespace App\Models;

class Address extends Model
{
    protected $table = 'address';
    public $timestamps = false;
    protected $appends = [];



}

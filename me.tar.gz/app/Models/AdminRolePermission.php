<?php

namespace App\Models;

class AdminRolePermission extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'admin_role_permission';
    public $timestamps = false;

}

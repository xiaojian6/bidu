<?php

/**
 * Created by PhpStorm.
 * User: swl
 * Date: 2018/7/3
 * Time: 10:23
 */

namespace App\Models;


use Illuminate\Support\Facades\DB;

class Redis extends Model
{
    protected $table = 'redis_test';
    public $timestamps = false;


}

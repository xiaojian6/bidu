<?php

namespace App\Models;

class AppApi extends Model
{
    protected $table = 'app_api';
}

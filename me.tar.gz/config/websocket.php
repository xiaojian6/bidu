<?php

return [
    'client' => [
        'callback_class' => \App\Utils\Workerman\WorkerCallback::class,
        'process_num' => 9,
    ],
];

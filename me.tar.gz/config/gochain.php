<?php

return [
    'gochain_api' => env('GOCHAIN_API','http://47.242.143.24'),
    'gochain_key' => env('GOCHAIN_KEY'),
];

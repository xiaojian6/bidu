<?php

return [
    'wallet_api' => env('WALLET_API', ''),
];

@extends('errors::layout')

@section('title', 'Forbidden')

@section('message', "Sorry,  权限不足！ ")
